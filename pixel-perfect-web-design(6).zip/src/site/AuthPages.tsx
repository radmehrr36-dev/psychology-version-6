import { useState, type FormEvent } from "react";
import { Link, Navigate, useLocation, useNavigate } from "react-router-dom";
import { Eye, EyeOff, Loader2, LockKeyhole, Mail, ShieldCheck, Stethoscope, UserRound } from "lucide-react";
import { useAuth } from "../lib/auth";
import { cn } from "../utils/cn";

const input =
  "w-full min-h-12 rounded-xl border border-ink/12 bg-white px-4 text-base text-ink placeholder:text-fog focus:border-steel focus:outline-none focus:ring-2 focus:ring-steel/15";

function AuthCard({ title, subtitle, icon: Icon, children }: { title: string; subtitle: string; icon: typeof UserRound; children: React.ReactNode }) {
  return (
    <div className="mx-auto w-full max-w-md rounded-[28px] border border-ink/8 bg-white/90 p-6 shadow-card backdrop-blur sm:p-8">
      <div className="mb-6 flex items-center gap-3">
        <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-steel/10 text-steel">
          <Icon className="h-5 w-5" strokeWidth={1.8} />
        </span>
        <div>
          <h1 className="text-xl font-semibold text-ink">{title}</h1>
          <p className="text-[14px] text-body">{subtitle}</p>
        </div>
      </div>
      {children}
    </div>
  );
}

function PasswordField({ value, onChange, autoComplete, minLength }: { value: string; onChange: (v: string) => void; autoComplete: string; minLength?: number }) {
  const [show, setShow] = useState(false);
  return (
    <div className="relative">
      <LockKeyhole className="pointer-events-none absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-fog" />
      <input
        type={show ? "text" : "password"}
        dir="ltr"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        autoComplete={autoComplete}
        minLength={minLength}
        required
        className={cn(input, "pr-10 pl-11 text-left")}
        placeholder="••••••••"
        aria-label="رمز عبور"
      />
      <button type="button" onClick={() => setShow((v) => !v)} aria-label={show ? "پنهان‌کردن رمز" : "نمایش رمز"} className="absolute left-2 top-1/2 flex h-9 w-9 -translate-y-1/2 items-center justify-center rounded-lg text-fog hover:text-ink">
        {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
      </button>
    </div>
  );
}

function useNextPath() {
  const location = useLocation();
  const params = new URLSearchParams(location.search);
  const next = params.get("next");
  return next && next.startsWith("/") && !next.startsWith("//") ? next : null;
}

export function LoginPage() {
  const { session, profile, loading, configured, isPsychologist, signIn, resetPassword } = useAuth();
  const navigate = useNavigate();
  const next = useNextPath();
  const [mode, setMode] = useState<"login" | "reset">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  if (!loading && session && profile) {
    return <Navigate to={next ?? (isPsychologist ? "/pro" : "/dashboard")} replace />;
  }

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setNotice(null);
    if (!configured) {
      setError("اتصال به سرویس حساب کاربری برقرار نیست.");
      return;
    }
    setBusy(true);
    if (mode === "reset") {
      const res = await resetPassword(email);
      setBusy(false);
      if (res.ok) setNotice("اگر این ایمیل ثبت شده باشد، لینک بازیابی رمز ارسال می‌شود.");
      else setError(res.error ?? "ارسال لینک بازیابی ناموفق بود.");
      return;
    }
    const res = await signIn(email, password);
    setBusy(false);
    if (!res.ok) setError(res.error ?? "ورود ناموفق بود.");
    else navigate(next ?? "/dashboard", { replace: true });
  };

  return (
    <AuthCard title={mode === "login" ? "ورود به آریاسازه" : "بازیابی رمز عبور"} subtitle={mode === "login" ? "به حساب کاربری یا پنل متخصص خود وارد شوید." : "لینک بازیابی به ایمیل شما ارسال می‌شود."} icon={UserRound}>
      <form onSubmit={submit} className="space-y-4" noValidate>
        <label className="block">
          <span className="mb-1.5 block text-[14px] font-bold text-ink">ایمیل</span>
          <div className="relative">
            <Mail className="pointer-events-none absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-fog" />
            <input type="email" dir="ltr" autoComplete="username" value={email} onChange={(e) => setEmail(e.target.value)} required className={cn(input, "pr-10 text-left")} placeholder="you@example.com" />
          </div>
        </label>
        {mode === "login" && (
          <label className="block">
            <span className="mb-1.5 block text-[14px] font-bold text-ink">رمز عبور</span>
            <PasswordField value={password} onChange={setPassword} autoComplete="current-password" />
          </label>
        )}
        {error && <p role="alert" className="rounded-xl bg-[#fbeceb] px-4 py-2.5 text-[14px] font-semibold leading-6 text-[#8f322d]">{error}</p>}
        {notice && <p role="status" className="rounded-xl bg-[#e9f6f2] px-4 py-2.5 text-[14px] font-semibold leading-6 text-[#256b5e]">{notice}</p>}
        <button type="submit" disabled={busy || !configured} className="inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-full bg-coral text-base font-bold text-ink shadow-soft transition-all hover:bg-coral-deep disabled:opacity-60">
          {busy && <Loader2 className="h-4 w-4 animate-spin" />}
          {mode === "login" ? "ورود" : "ارسال لینک بازیابی"}
        </button>
      </form>
      <div className="mt-4 flex flex-wrap items-center justify-between gap-2 text-[14px]">
        <button type="button" onClick={() => { setMode(mode === "login" ? "reset" : "login"); setError(null); setNotice(null); }} className="font-semibold text-steel hover:text-ink">
          {mode === "login" ? "رمز عبور را فراموش کرده‌اید؟" : "بازگشت به ورود"}
        </button>
        <Link to={next ? `/register?next=${encodeURIComponent(next)}` : "/register"} className="font-semibold text-body hover:text-ink">
          حساب ندارید؟ ثبت‌نام
        </Link>
      </div>
      <p className="mt-5 flex items-start gap-2 rounded-xl bg-cream px-3.5 py-2.5 text-[13px] leading-6 text-body">
        <ShieldCheck className="mt-1 h-3.5 w-3.5 shrink-0 text-steel" />
        مدیران سایت از <Link to="/admin/login" className="mx-1 font-bold text-steel">ورود مدیران</Link> استفاده می‌کنند.
      </p>
    </AuthCard>
  );
}

const SPECIALTIES = ["اضطراب و استرس", "افسردگی و خلق", "روابط و خانواده", "کودک و نوجوان", "رشد فردی", "اعتیاد", "تروما", "مشاوره‌ی تحصیلی و شغلی"];

export function RegisterPage() {
  const { session, profile, loading, configured, signUp } = useAuth();
  const navigate = useNavigate();
  const next = useNextPath();
  const location = useLocation();
  const initialKind = new URLSearchParams(location.search).get("kind") === "psychologist" ? "psychologist" : "user";
  const [kind, setKind] = useState<"user" | "psychologist">(initialKind);
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [accepted, setAccepted] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState<"confirm" | null>(null);

  if (!loading && session && profile && !done) {
    return <Navigate to={next ?? (kind === "psychologist" ? "/pro/apply" : "/dashboard")} replace />;
  }

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!configured) return setError("اتصال به سرویس حساب کاربری برقرار نیست.");
    if (fullName.trim().length < 2) return setError("نام و نام خانوادگی را وارد کنید.");
    if (password.length < 8) return setError("رمز عبور باید حداقل ۸ کاراکتر باشد.");
    if (!accepted) return setError("پذیرش قوانین و حریم خصوصی لازم است.");
    setBusy(true);
    const res = await signUp({ email, password, fullName, kind });
    setBusy(false);
    if (!res.ok) return setError(res.error ?? "ثبت‌نام ناموفق بود.");
    if (res.needsConfirmation) return setDone("confirm");
    navigate(next ?? (kind === "psychologist" ? "/pro/apply" : "/dashboard"), { replace: true });
  };

  if (done === "confirm") {
    return (
      <AuthCard title="ایمیل خود را تأیید کنید" subtitle="لینک فعال‌سازی برای شما ارسال شد." icon={Mail}>
        <p className="text-[15px] leading-8 text-body">
          برای فعال‌شدن حساب، روی لینک ارسال‌شده به <span dir="ltr" className="font-bold text-ink">{email}</span> کلیک کنید. سپس وارد شوید
          {kind === "psychologist" ? " و فرم همکاری متخصص را تکمیل کنید." : "."}
        </p>
        <Link to="/login" className="mt-5 inline-flex min-h-12 w-full items-center justify-center rounded-full bg-ink text-base font-bold text-white">
          رفتن به صفحه‌ی ورود
        </Link>
      </AuthCard>
    );
  }

  return (
    <AuthCard title="ساخت حساب" subtitle="برای انجام آزمون‌ها و دیدن گزارش‌ها حساب بسازید." icon={kind === "psychologist" ? Stethoscope : UserRound}>
      <div role="radiogroup" aria-label="نوع حساب" className="mb-5 grid grid-cols-2 gap-1 rounded-2xl bg-cream-alt p-1">
        {(
          [
            ["user", "کاربر", UserRound],
            ["psychologist", "متخصص روان‌شناسی", Stethoscope],
          ] as const
        ).map(([k, label, Icon]) => (
          <button key={k} type="button" role="radio" aria-checked={kind === k} onClick={() => setKind(k)} className={cn("flex min-h-11 items-center justify-center gap-2 rounded-xl text-[14px] font-bold transition-all", kind === k ? "bg-white text-steel shadow-sm" : "text-body hover:text-ink")}>
            <Icon className="h-4 w-4" />
            {label}
          </button>
        ))}
      </div>
      {kind === "psychologist" && (
        <p className="mb-4 rounded-xl bg-steel/5 px-3.5 py-2.5 text-[13px] leading-6 text-body">
          پس از ساخت حساب، فرم اطلاعات حرفه‌ای را تکمیل می‌کنید. پروفایل شما پس از بررسی و تأیید مدارک توسط تیم آریاسازه فعال می‌شود.
        </p>
      )}
      <form onSubmit={submit} className="space-y-4" noValidate>
        <label className="block">
          <span className="mb-1.5 block text-[14px] font-bold text-ink">نام و نام خانوادگی</span>
          <input value={fullName} onChange={(e) => setFullName(e.target.value)} autoComplete="name" required className={input} />
        </label>
        <label className="block">
          <span className="mb-1.5 block text-[14px] font-bold text-ink">ایمیل</span>
          <input type="email" dir="ltr" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} required className={cn(input, "text-left")} placeholder="you@example.com" />
        </label>
        <label className="block">
          <span className="mb-1.5 block text-[14px] font-bold text-ink">رمز عبور (حداقل ۸ کاراکتر)</span>
          <PasswordField value={password} onChange={setPassword} autoComplete="new-password" minLength={8} />
        </label>
        <label className="flex items-start gap-2.5 text-[14px] leading-6 text-body">
          <input type="checkbox" checked={accepted} onChange={(e) => setAccepted(e.target.checked)} className="mt-1.5 h-4 w-4 accent-[#3f5e78]" />
          <span>
            <Link to="/p/terms" className="font-bold text-steel">قوانین</Link> و <Link to="/p/privacy" className="font-bold text-steel">حریم خصوصی</Link> را می‌پذیرم. آزمون‌ها برای خودشناسی‌اند و جایگزین تشخیص یا درمان نیستند.
          </span>
        </label>
        {error && <p role="alert" className="rounded-xl bg-[#fbeceb] px-4 py-2.5 text-[14px] font-semibold leading-6 text-[#8f322d]">{error}</p>}
        <button type="submit" disabled={busy || !configured} className="inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-full bg-coral text-base font-bold text-ink shadow-soft transition-all hover:bg-coral-deep disabled:opacity-60">
          {busy && <Loader2 className="h-4 w-4 animate-spin" />}
          ساخت حساب
        </button>
      </form>
      <p className="mt-4 text-center text-[14px] text-body">
        قبلاً ثبت‌نام کرده‌اید؟ <Link to={next ? `/login?next=${encodeURIComponent(next)}` : "/login"} className="font-bold text-steel">وارد شوید</Link>
      </p>
      <p className="sr-only">{SPECIALTIES.length} حوزه‌ی تخصصی در فرم همکاری قابل انتخاب است.</p>
    </AuthCard>
  );
}

/** محافظ مسیرهای نیازمند ورود (کاربر یا متخصص) */
export function RequireAuth({ children, psychologistOnly = false }: { children: React.ReactNode; psychologistOnly?: boolean }) {
  const { session, loading, configured, isPsychologist } = useAuth();
  const location = useLocation();
  if (!configured) {
    return (
      <div className="mx-auto max-w-md rounded-[28px] border border-ink/8 bg-white p-6 text-center text-[15px] leading-7 text-body">
        حساب کاربری نیازمند اتصال به Supabase است و در این نسخه پیکربندی نشده.
      </div>
    );
  }
  if (loading) {
    return (
      <div className="flex items-center justify-center gap-2 py-24 text-[15px] text-body" role="status">
        <Loader2 className="h-4 w-4 animate-spin" />
        بررسی حساب…
      </div>
    );
  }
  if (!session) return <Navigate to={`/login?next=${encodeURIComponent(location.pathname + location.search)}`} replace />;
  if (psychologistOnly && !isPsychologist) return <Navigate to="/pro/apply" replace />;
  return <>{children}</>;
}
